package jeju.bear.plan.entity;

public enum PlaceType {

    ACCOMMODATION,
    RESTAURANT,
    TOURIST
}
