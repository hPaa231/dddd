package jeju.bear.plan.entity;

public enum Transportation {

    CAR,
    TAXI,
    BUS,
    WALK

}
