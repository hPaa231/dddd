package jeju.bear.plan.util;

public class ScheduleCalculator {
}
