package jeju.bear.plan.util.optimization;

public class OrToolsSolver {
}
